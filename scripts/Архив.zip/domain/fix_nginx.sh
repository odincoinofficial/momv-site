#!/bin/bash

LOGFILE="/var/log/nginx_config_fix.log"
NGINX_CONF="/etc/nginx/nginx.conf"
SITES_ENABLED="/etc/nginx/sites-enabled"

echo "===== $(date) - Starting nginx config fix =====" >> $LOGFILE

# 1. Проверка include строки
if grep -q 'include /etc/nginx/sites-enabled/\*\.conf;' "$NGINX_CONF"; then
    echo "[+] Замена *.conf на *.online.conf..." | tee -a $LOGFILE
    sed -i 's|include /etc/nginx/sites-enabled/\*\.conf;|include /etc/nginx/sites-enabled/*.online.conf;|' "$NGINX_CONF"
else
    echo "[i] Строка include уже изменена или отсутствует." | tee -a $LOGFILE
fi

# 2. Проверка конфигурации
echo "[*] Проверка конфигурации..." | tee -a $LOGFILE
if nginx -t 2>> $LOGFILE; then
    echo "[+] Конфигурация валидна. Перезапускаем nginx..." | tee -a $LOGFILE
    systemctl reload nginx
    systemctl status nginx | tee -a $LOGFILE
else
    echo "[!] Ошибка в конфигурации nginx. Проверьте лог: $LOGFILE" | tee -a $LOGFILE
fi

echo "===== $(date) - Finished =====" >> $LOGFILE
