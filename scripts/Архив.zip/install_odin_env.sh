
#!/bin/bash

echo "🔧 Обновляем систему..."
apt update && apt upgrade -y

echo "📦 Устанавливаем системные пакеты..."
apt install -y curl wget unzip zip git nano gnupg software-properties-common \
python3 python3-pip nodejs npm nginx ufw qrencode \
apt-transport-https ca-certificates lsb-release

echo "🐍 Устанавливаем Python-зависимости..."
pip3 install --upgrade pip
pip3 install fastapi uvicorn[standard] aiohttp pydantic requests python-multipart aiofiles jinja2 qrcode python-dotenv sqlalchemy asyncpg aiogram weasyprint

echo "🛠️ Устанавливаем WireGuard VPN и инструменты..."
apt install -y wireguard wireguard-tools resolvconf

echo "🐘 Устанавливаем PostgreSQL..."
apt install -y postgresql postgresql-contrib

echo "🔧 Установка завершена. Перезапускаем nginx..."
systemctl restart nginx

echo "✅ Все зависимости установлены."
